I keep copies of hibernate*.jar, commons*.jar and other libraries
that we can assume you have if you are running grails yet are not
necessarily contained in $GRAILS_HOME/lib 
