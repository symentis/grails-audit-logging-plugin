class AuditLogEventTests extends GroovyTestCase {

    void testSomething() {

    }
}
